﻿using TravelTales.Domain.Entities;

namespace TravelTales.Persistence.Interfaces
{
    public interface IRoleRepository : IGenericRepository<Role, Guid>
    {
    }
}
