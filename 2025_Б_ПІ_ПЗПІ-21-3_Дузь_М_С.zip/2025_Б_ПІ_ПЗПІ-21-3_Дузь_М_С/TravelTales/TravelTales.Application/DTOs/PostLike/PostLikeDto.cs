﻿namespace TravelTales.Application.DTOs.PostLike
{
    public class PostLikeDto
    {
        public long PostId { get; set; }
        public long BloggerId { get; set; }
    }
}
