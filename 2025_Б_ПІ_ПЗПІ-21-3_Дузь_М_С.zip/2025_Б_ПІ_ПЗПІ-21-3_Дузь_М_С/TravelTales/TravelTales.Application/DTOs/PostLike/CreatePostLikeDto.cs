﻿namespace TravelTales.Application.DTOs.PostLike
{
    public class CreatePostLikeDto
    {
        public long PostId { get; set; }
        public long BloggerId { get; set; }
    }
}
