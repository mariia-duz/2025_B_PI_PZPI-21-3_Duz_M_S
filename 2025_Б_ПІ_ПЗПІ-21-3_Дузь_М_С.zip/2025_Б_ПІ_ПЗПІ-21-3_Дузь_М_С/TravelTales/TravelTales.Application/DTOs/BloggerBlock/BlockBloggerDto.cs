﻿namespace TravelTales.Application.DTOs.BloggerBlock
{
    public class BlockBloggerDto
    {
        public long BlockerId { get; set; }
        public long BlockedId { get; set; }
    }
}
