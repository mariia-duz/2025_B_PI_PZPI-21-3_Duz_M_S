﻿namespace TravelTales.Application.DTOs.BloggerBlock
{
    public class UnblockBloggerDto
    {
        public long BlockerId { get; set; }
        public long UnblockedId { get; set; }
    }
}
