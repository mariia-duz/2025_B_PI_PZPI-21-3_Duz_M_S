﻿namespace TravelTales.Application.DTOs.Auth
{
    public class PasswordChangeDto
    {
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
    }
}
