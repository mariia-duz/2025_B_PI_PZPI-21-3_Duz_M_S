﻿namespace TravelTales.Application.DTOs.Auth
{
    public class GoogleSignInDto
    {
        public string Token { get; set; }
    }
}
