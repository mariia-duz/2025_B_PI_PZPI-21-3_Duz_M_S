﻿using TravelTales.Application.DTOs.Post;

namespace TravelTales.Application.DTOs.Category
{
    public class CreateCategoryDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string NameUa { get; set; }
        public string DescriptionUa { get; set; }
    }
}
