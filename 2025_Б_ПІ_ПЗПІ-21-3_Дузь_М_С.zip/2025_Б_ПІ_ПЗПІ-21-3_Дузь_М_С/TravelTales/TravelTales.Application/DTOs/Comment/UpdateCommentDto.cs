﻿namespace TravelTales.Application.DTOs.Comment
{
    public class UpdateCommentDto
    {
        public string Content { get; set; }
    }
}
