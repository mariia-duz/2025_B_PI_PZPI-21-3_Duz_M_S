﻿namespace TravelTales.Application.DTOs.Role
{
    public class CreateRoleDto
    {
        public string Name { get; set; }
    }
}
