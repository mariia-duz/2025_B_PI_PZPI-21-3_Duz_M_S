﻿namespace TravelTales.Application.DTOs.Role
{
    public class UpdateRoleDto
    {
        public string Name { get; set; }
    }
}
