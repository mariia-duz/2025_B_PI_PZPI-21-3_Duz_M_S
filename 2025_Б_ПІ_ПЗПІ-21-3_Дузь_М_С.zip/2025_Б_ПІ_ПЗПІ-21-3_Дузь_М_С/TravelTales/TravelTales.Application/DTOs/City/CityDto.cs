﻿namespace TravelTales.Application.DTOs.City
{
    public class CityDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public long CountryId { get; set; }
    }
}
