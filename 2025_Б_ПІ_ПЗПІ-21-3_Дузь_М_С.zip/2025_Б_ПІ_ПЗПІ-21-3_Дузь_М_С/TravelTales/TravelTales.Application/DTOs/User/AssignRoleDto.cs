﻿namespace TravelTales.Application.DTOs.User
{
    public class AssignRoleDto
    {
        public Guid UserId { get; set; }

        public Guid RoleId { get; set; }
    }
}
