﻿namespace TravelTales.Application.DTOs.User
{
    public class UpdateUserDto
    {
    }
}
