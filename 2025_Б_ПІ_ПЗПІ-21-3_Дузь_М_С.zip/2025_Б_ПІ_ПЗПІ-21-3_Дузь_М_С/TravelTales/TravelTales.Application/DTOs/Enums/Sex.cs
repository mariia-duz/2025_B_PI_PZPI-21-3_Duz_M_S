﻿namespace TravelTales.Application.DTOs.Enums
{
    public enum Sex
    {
        Male,
        Female,
        Other
    }
}
