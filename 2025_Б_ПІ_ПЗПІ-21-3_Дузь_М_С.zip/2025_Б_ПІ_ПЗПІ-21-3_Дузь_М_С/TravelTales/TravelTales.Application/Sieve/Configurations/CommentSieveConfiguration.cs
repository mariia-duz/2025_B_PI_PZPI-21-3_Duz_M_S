﻿using Sieve.Services;
using TravelTales.Domain.Entities;

namespace TravelTales.Application.Sieve.Configurations
{
    public class CommentSieveConfiguration : ISieveConfiguration
    {
        public void Configure(SievePropertyMapper mapper)
        {
            ArgumentNullException.ThrowIfNull(mapper);

            mapper.Property<Comment>(x => x.PostId)
                .CanFilter()
                .CanSort();

            mapper.Property<Comment>(x => x.CreatedAt)
                .CanFilter()
                .CanSort();
        }
    }
}
