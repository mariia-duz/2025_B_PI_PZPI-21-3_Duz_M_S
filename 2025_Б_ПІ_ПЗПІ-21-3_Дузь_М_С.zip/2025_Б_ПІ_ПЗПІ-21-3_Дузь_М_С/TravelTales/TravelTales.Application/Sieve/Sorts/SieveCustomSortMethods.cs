﻿using Sieve.Services;

namespace TravelTales.Application.Sieve.Sorts
{
    public class SieveCustomSortMethods: ISieveCustomSortMethods
    {
    }
}
