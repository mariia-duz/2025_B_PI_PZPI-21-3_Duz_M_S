﻿namespace TravelTales.Application.Constants
{
    public partial class TravelTalesConstants
    {
        public class TravelTalesPermissions
        {
            public static class App
            {
                public const string List = "TravelTales.List";
                public const string View = "TravelTales.View";
                public const string Create = "TravelTales.Create";
                public const string Update = "TravelTales.Update";
                public const string Delete = "TravelTales.Delete";
            }
        }
    }
}
