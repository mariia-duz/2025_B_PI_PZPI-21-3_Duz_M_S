﻿namespace TravelTales.Application.Constants
{
    public partial class TravelTalesConstants
    {
        public class ClaimTypes
        {
            public const string Permissions = "Permisssions";
        }
    }
}
