﻿namespace TravelTales.Domain.Enums
{
    public enum BudgetLevel
    {
        Low = 0,        // $0 - $500
        Medium = 1,     // $500 - $2000
        High = 2,       // $2000 - $5000
        Luxury = 3,     // $5000+
        NotSpecified = 4
    }
}