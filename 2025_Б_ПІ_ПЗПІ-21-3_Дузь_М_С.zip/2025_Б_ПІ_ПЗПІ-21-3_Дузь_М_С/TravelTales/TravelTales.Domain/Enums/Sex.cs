﻿namespace TravelTales.Domain.Enums
{
    public enum Sex
    {
        Male,
        Female,
        Other
    }
}
